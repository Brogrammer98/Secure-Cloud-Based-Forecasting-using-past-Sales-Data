import matplotlib.pyplot as plt 
import csv
import sklearn.metrics as sk
import math
# import numpy as np
import decimal
decimal.setcontext(decimal.Context(prec=40))

def create_pred_seq_1(x, a):
	s = x[0]
	ans = [s]
	for t in range(1,len(x)):
		s = a*x[t] + (1-a)*s
		ans.append(s)

	return ans

def create_pred_seq_1_exp(x, a, n):
	s = []
	for t in range(0,len(x)):
		val = 0
		coeff = a 
		for i in range(n):
			if t-i>1:
				val+= coeff*x[t-i]
				coeff *= (1-a)
			if t-i == 0:
				val+=coeff*x[0]/a
				break
		s.append(val)

	return s

def create_pred_seq_2(x, a, beta):
	s1 = x[1]
	b1 = x[1] - x[0]
	ans = [None, None, s1 + b1]
	for t in range(2,len(x)):
		s2 = a*x[t] + (1-a)*(s1+b1)
		b1 = beta*(s2-s1) + (1-beta)*b1
		s1=s2
		ans.append(s1 + b1)

	return ans

def create_pred_seq_brown(x, alpha):
	s0 = x[0]
	s00 = x[0]
	a = 2*s0 - s00
	b = alpha/(1-alpha)*(s0 - s00)
	ans = [None, a + b]
	for t in range(1,len(x)):
		s0 = alpha*x[t] + (1-alpha)*s0
		s00 = alpha*s0 + (1-alpha)*s00
		a = 2*s0 - s00
		b = alpha/(1-alpha)*(s0 - s00)
		ans.append(a + b)

	return ans

def create_pred_seq_3_m(x, alpha, beta, gama, N, L):
	s = [x[0]]

	b_add = 0
	b_sub = 0 
	for t in range(1,L+1):
		b_sub += x[t]

	for t in range(L+1,L+L+1):
		b_add += x[t]

	b = [(b_add-b_sub)/L/L]
	
	c = [None]
	for i in range(1,L+1):	
		cval = 0
		for j in range(N):
			val = 0
			for k in range(1,L+1):
				val+=x[L*j+k]
			A = val/L
			cval += x[L*j+i]/A

		c.append(cval/N)

	
	ans = [None, s[0]+b[0]]
	for t in range(1,len(x)):
		if t<=L:
			st = alpha*x[t] + (1-alpha)*(s[t-1]+b[t-1])
			s.append(st)
			bt = beta*(st - s[t-1]) + (1-beta)*b[t-1]
			b.append(bt)
			if t < L:
				ans.append(st+bt)
			else: 
				ans.append((st+bt)*c[t-L+1])

		else:
			st = alpha*x[t]/c[t-L] + (1-alpha)*(s[t-1]+b[t-1])
			s.append(st)
			bt = beta*(st - s[t-1]) + (1-beta)*b[t-1]
			b.append(bt)
			ct = gama*x[t]/s[t] + (1-gama)*c[t-L]
			c.append(ct)
			ans.append((st+bt)*c[t-L+1])	

	# print("SSSSSSSSSSSSSSSSSSSSSSSSSS\n",s)
	# print("CCCCCCCCCCCCCCCCCCCCCCCCCC\n",c)
	return ans

def create_pred_seq_3_m_bd(x, alpha, beta, gama, N, L, cdash, sdash):
	s = [x[0]]

	b_add = 0
	b_sub = 0 
	for t in range(1,L+1):
		b_sub += x[t]

	for t in range(L+1,L+L+1):
		b_add += x[t]

	b = [(b_add-b_sub)/L/L]
	
	c = [None]
	for i in range(1,L+1):	
		cval = 0
		for j in range(N):
			val = 0
			for k in range(1,L+1):
				val+=x[L*j+k]
			A = val/L
			cval += x[L*j+i]/A

		c.append(cval/N)

	
	ans = [None, s[0]+b[0]]
	for t in range(1,len(x)):
		if t<=L:
			st = alpha*x[t] + (1-alpha)*(s[t-1]+b[t-1])
			s.append(st)
			bt = beta*(st - s[t-1]) + (1-beta)*b[t-1]
			b.append(bt)
			if t < L:
				ans.append(st+bt)
			else: 
				ans.append((st+bt)*c[t-L+1])

		else:
			st = alpha*((-x[t]/cdash**4)*c[t-L]**3 + (4*x[t]/cdash**3)*c[t-L]**2 - (6*x[t]/cdash**2)*c[t-L] + 4*x[t]/cdash) + (1-alpha)*(s[t-1]+b[t-1])
			s.append(st)
			bt = beta*(st - s[t-1]) + (1-beta)*b[t-1]
			b.append(bt)
			stemp = s[t]/sdash
			# print(stemp)
			ct = gama*x[t]/sdash*(-stemp**3 + 4*stemp**2 - 6*stemp + 4) + (1-gama)*c[t-L]
			c.append(ct)
			ans.append((st+bt)*c[t-L+1])	

	# print("SSSSSSSSSSSSSSSSSSSSSSSSSS\n",s)
	# print("CCCCCCCCCCCCCCCCCCCCCCCCCC\n",c)
	return ans


def create_pred_seq_3_a(x, alpha, beta, gama, N, L):
	s = [x[0]]

	b_add = 0
	b_sub = 0 
	for t in range(1,L+1):
		b_sub += x[t]

	for t in range(L+1,L+L+1):
		b_add += x[t]

	b = [(b_add-b_sub)/L/L]
	
	c = [None]
	for i in range(1,L+1):	
		cval = 0
		for j in range(N):
			val = 0
			for k in range(1,L+1):
				val+=x[L*j+k]
			A = val/L
			cval += x[L*j+i]/A

		c.append(cval/N)

	
	ans = [None, s[0]+b[0]]
	for t in range(1,len(x)):
		if t<=L:
			st = alpha*x[t] + (1-alpha)*(s[t-1]+b[t-1])
			s.append(st)
			bt = beta*(st - s[t-1]) + (1-beta)*b[t-1]
			b.append(bt)
			if t < L:
				ans.append(st+bt)
			else: 
				ans.append(st+bt+c[t-L+1])

		else:
			st = alpha*(x[t]-c[t-L]) + (1-alpha)*(s[t-1]+b[t-1])
			s.append(st)
			bt = beta*(st - s[t-1]) + (1-beta)*b[t-1]
			b.append(bt)
			ct = gama*(x[t]-s[t-1]-b[t-1]) + (1-gama)*c[t-L]
			c.append(ct)
			ans.append(st+bt+c[t-L+1])	

	# print("SSSSSSSSSSSSSSSSSSSSSSSSSS\n",s)
	# print("CCCCCCCCCCCCCCCCCCCCCCCCCC\n",c)
	return ans

def do_error_analysis(x,s):
	forecast_errors = [x[i]-s[i] for i in range(len(x))]
	relative_errors = [abs(forecast_errors[i]/x[i]) for i in range(len(x))]
	print("-----------Mean Forecast Error: ", sum(forecast_errors)*1.0/len(forecast_errors))
	print("-----------Mean Absolute Error: ", sk.mean_absolute_error(x,s))
	print("-----------Root Mean Squared Error: ", math.sqrt(sk.mean_squared_error(x,s)))
	print("-----------Mean Absolute Percentage Error (out of 100%): ", sum(relative_errors)*100.0/len(relative_errors))


x = []
y0 = []

with open("Mean_Temp_IMD_2017.csv", "r") as csvfile:
	plots= list(csv.reader(csvfile, delimiter=','))
	colnames = plots[0]
	for row in plots[1:21]: ################### Change to number of plots you want, will have to change number of known cycles appropriately
		for i in range(1,13):
			x.append(str(row[0])+colnames[i])
			y0.append(float(row[i]))

	x.append(str(plots[21][0])+colnames[1])
	y0.append(float(plots[21][1]))

x.append("Final Prediction")
# print(x)
# print(y0)
######################################################################
"""
Basic Exponential Smoothing. Has one parameter alpha, which I am varying from within 0.25, 0.5, 0.75. Corresponding plots are 
	basic_0.25_0.5_0.75.png (s values shifted by one)
	basic_0.25_0.5_0.75_50_s.png (Plotted with 50 cycles of data)
	basic_no_shift.png 
Larger alpha gives better smoothing hence continuing with alpha = 0.75.
"""
s1 = create_pred_seq_1(y0, 0.25)
s2 = create_pred_seq_1(y0, 0.5)
s3 = create_pred_seq_1(y0, 0.75)
print("Basic Exponential Smoothing : Alpha = 0.25")
do_error_analysis(y0,s1)
print("Basic Exponential Smoothing : Alpha = 0.5")
do_error_analysis(y0,s2)
print("Basic Exponential Smoothing : Alpha = 0.75")
do_error_analysis(y0,s3)
print("\n")

# plt.plot(x[:-1],y0,'b',  marker='o')
# plt.plot(x[:-1],s1,'g',  marker='o')
# plt.plot(x[:-1],s2,'r',  marker='o')
# plt.plot(x[:-1],s3,'y', marker='o')

########################################################################
"""
Double Exponential Smoothing. Has two parameters alpha and beta, in which I am varying beta from within 0.25, 0.5, 0.75. Corresponding plots are 
	sec_a=0.25.png (tried with alpha = 0.25)
	sec_a=0.75.png (tried with alpha = 0.75)
Continuing with alpha = 0.75, beta = 0.25.
"""
s1 = create_pred_seq_2(y0, 0.75, 0.25)
s2 = create_pred_seq_2(y0, 0.75, 0.5)
s3 = create_pred_seq_2(y0, 0.75, 0.75)
print("Double Exponential Smoothing : Alpha = 0.75, Beta = 0.25")
do_error_analysis(y0[2:],s1[2:-1])
print("Double Exponential Smoothing : Alpha = 0.75, Beta = 0.5")
do_error_analysis(y0[2:],s2[2:-1])
print("Double Exponential Smoothing : Alpha = 0.75, Beta = 0.75")
do_error_analysis(y0[2:],s3[2:-1])
print("\n")

# plt.plot(x[:-1],y0,'b',  marker='o')
# plt.plot(x,s1,'g',  marker='o')
# plt.plot(x,s2,'r',  marker='o')
# plt.plot(x,s3,'y', marker='o')

###################################################################
"""
Brown Exponential Smoothing. Has one parameter alpha, which I am varying from within 0.25, 0.5, 0.75. Corresponding plot is
	brown_0.25_0.5_0.75.png
"""
s1 = create_pred_seq_brown(y0, 0.25)
s2 = create_pred_seq_brown(y0, 0.5)
s3 = create_pred_seq_brown(y0, 0.75)
print("Brown Exponential Smoothing : Alpha = 0.25")
do_error_analysis(y0[1:],s1[1:-1])
print("Brown Exponential Smoothing : Alpha = 0.5")
do_error_analysis(y0[1:],s2[1:-1])
print("Brown Exponential Smoothing : Alpha = 0.75")
do_error_analysis(y0[1:],s3[1:-1])
print("\n")

# plt.plot(x[:-1],y0,'b',  marker='o')
# plt.plot(x,s1,'g',  marker='o')
# plt.plot(x,s2,'r',  marker='o')
# plt.plot(x,s3,'y', marker='o')

#################################################################
"""
Triple Exponential Smoothing with Multiplicative Seasonality. Has five parameters alpha, beta, gamma, N, L, in which I am varying gamma from within 0.25, 0.5, 0.75. 
N is number of complete cycles for which data is completely known. L is the length of a cycle. Corresponding plot is
	trip_m.png
Continuing with alpha = 0.75, beta = 0.25, gamma = 0.5.
"""
s1 = create_pred_seq_3_m(y0, 0.75, 0.25, 0.25, 20, 12)
s2 = create_pred_seq_3_m(y0, 0.75, 0.25, 0.5, 20, 12)
s3 = create_pred_seq_3_m(y0, 0.75, 0.25, 0.75, 20, 12)
print("Triple Exponential Smoothing Multiplicative: Alpha = 0.75, Beta = 0.25, Gamma = 0.25")
do_error_analysis(y0[1:],s1[1:-1])
print("Triple Exponential Smoothing Multiplicative: Alpha = 0.75, Beta = 0.25, Gamma = 0.5")
do_error_analysis(y0[1:],s2[1:-1])
print("Triple Exponential Smoothing Multiplicative: Alpha = 0.75, Beta = 0.25, Gamma = 0.75")
do_error_analysis(y0[1:],s3[1:-1])
print("\n")

# plt.plot(x[:-1],y0,'b',  marker='o')
# plt.plot(x,s1,'g',  marker='o')
# plt.plot(x,s2,'r',  marker='o')
# plt.plot(x,s3,'y', marker='o')

###################################################################
"""
Triple Exponential Smoothing with Additive Seasonality. Has five parameters alpha, beta, gamma, N, L, in which I am varying gamma from within 0.25, 0.5, 0.75. 
N is number of complete cycles for which data is completely known (here 20). L is the length of a cycle (here 12). Corresponding plot is
	trip_a.png
"""
s1 = create_pred_seq_3_a(y0, 0.75, 0.25, 0.25, 20, 12)
s2 = create_pred_seq_3_a(y0, 0.75, 0.25, 0.5, 20, 12)
s3 = create_pred_seq_3_a(y0, 0.75, 0.25, 0.75, 20, 12)
print("Triple Exponential Smoothing Additive: Alpha = 0.75, Beta = 0.25, Gamma = 0.25")
do_error_analysis(y0[1:],s1[1:-1])
print("Triple Exponential Smoothing Additive: Alpha = 0.75, Beta = 0.25, Gamma = 0.5")
do_error_analysis(y0[1:],s2[1:-1])
print("Triple Exponential Smoothing Additive: Alpha = 0.75, Beta = 0.25, Gamma = 0.75")
do_error_analysis(y0[1:],s3[1:-1])
print("\n")

# plt.plot(x[:-1],y0,'b',  marker='o')
# plt.plot(x,s1,'g',  marker='o')
# plt.plot(x,s2,'r',  marker='o')
# plt.plot(x,s3,'y', marker='o')

##################################################################
"""
Triple Exponential Smoothing with Multiplicative Seasonality : Division and Pseudo Division. Has seven parameters alpha, beta, gamma, N, L, cdash, sdash in which I am varying sdash from within 19.0, 24.0, 30.0 for errors. 
'cdash' is the approximate value of c to be used for pseudo-division, there's no need to change, as for sales data or temperature data, c is always close to 1.0.
'sdash' is the approximate value of s to be used for pseudo-division. Can be calculated as an average of all current data.
Corresponding plot is for cdash = 1.0, sdash = 24.0.
	trip_m.png
"""
s1 = create_pred_seq_3_m(y0, 0.75, 0.25, 0.5, 20, 12)
s2 = create_pred_seq_3_m_bd(y0, 0.75, 0.25, 0.5, 20, 12, 1.0, 19.0) ###### use sdash >= 19.0
s3 = create_pred_seq_3_m_bd(y0, 0.75, 0.25, 0.5, 20, 12, 1.0, 24.0)
s4 = create_pred_seq_3_m_bd(y0, 0.75, 0.25, 0.5, 20, 12, 1.0, 30.0)
print("Triple Exponential Smoothing M Division and Pseudo-Division : Alpha = 0.75, Beta = 0.25, Gamma = 0.5, Approx C = 1.0, Approx S = 19.0")
do_error_analysis(s1[1:],s2[1:])
print("Triple Exponential Smoothing M Division and Pseudo-Division : Alpha = 0.75, Beta = 0.25, Gamma = 0.5, Approx C = 1.0, Approx S = 24.0")
do_error_analysis(s1[1:],s3[1:])
print("Triple Exponential Smoothing M Division and Pseudo-Division : Alpha = 0.75, Beta = 0.25, Gamma = 0.5, Approx C = 1.0, Approx S = 30.0")
do_error_analysis(s1[1:],s4[1:])
print("\n")


# plt.plot(x[:-1],y0,'b',  marker='o')
# plt.plot(x,s1,'g',  marker='o')
# plt.plot(x,s2,'r',  marker='o')

#################################################################
"""
Recursive vs Iterative Basic Exponential Smoothing, where recursive is the complete calculation starting from the initial value, while iterative is the prediction using some recent N values.
Corresponding plot uses N = 5 and N = 12.
	basic_exp_5_12.png
"""
s1 = create_pred_seq_1(y0, 0.75)
s2 = create_pred_seq_1_exp(y0, 0.75, 5)
s3 = create_pred_seq_1_exp(y0, 0.75, 12)
print("Basic Exponential Smoothing Recv vs Iter : Alpha = 0.75, No. of Past values = 5")
do_error_analysis(s1,s2)
print("Basic Exponential Smoothing Recv vs Iter : Alpha = 0.75, No. of Past values = 12")
do_error_analysis(s1,s3)
print("\n")

# plt.plot(x[:-1],y0,'b',  marker='o')
# plt.plot(x[1:],s1,'g',  marker='o')
# plt.plot(x[1:],s2,'r',  marker='o')
# plt.plot(x[1:],s3,'y',  marker='o')

"""
Uncomment the nest part till the end for plotting
"""
# plt.title('Data from the CSV File: Months and Temps')

# plt.xlabel('Months')
# plt.ylabel('Temps')

# plt.show()
