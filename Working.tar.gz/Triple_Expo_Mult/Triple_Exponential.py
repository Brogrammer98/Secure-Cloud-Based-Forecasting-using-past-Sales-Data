import csv
import sklearn.metrics as sk
import math
import numpy as np
import decimal
import glob
decimal.setcontext(decimal.Context(prec=40))
import warnings
warnings.filterwarnings("ignore", category=RuntimeWarning) 

"""
Triple Exponential Smoothing with Multiplicative Seasonality. Has five parameters alpha, beta, gamma, N, L.
N is number of complete cycles for which data is completely known. L is the length of a cycle. 
Forecasting using triple exponential multiplicative seasonality.
"""

def create_pred_seq_3_mul(x, alpha, beta, gama, N, L, m):
	alpha=alpha * .01
	beta = beta * .01
	gama=gama * .01

	s = [x[0]]

	b_add = 0
	b_sub = 0 
	for t in range(1,L+1):
		b_sub += x[t]

	for t in range(L+1,L+L+1):
		b_add += x[t]

	b = [(b_add-b_sub)/L/L]
	
	c = [None]
	for i in range(1,L+1):	
		cval = 0
		for j in range(N):
			val = 0
			for k in range(1,L+1):
				val+=x[L*j+k]
			A = val/L
			cval += x[L*j+i]/A

		c.append(cval/N)

	
	forecast = [None] 
	while(len(forecast)!=(m)):
		forecast.append(None)

	forecast.append(s[0]+m*b[0])
	for t in range(1,len(x)):
		if t<=L:
			st = alpha*x[t] + (1-alpha)*(s[t-1]+b[t-1])
			s.append(st)

			bt = beta*(s[t] - s[t-1]) + (1-beta)*b[t-1]
			b.append(bt)

			if t < L:
				forecast.append(s[t]+m*b[t])
			else: 
				forecast.append((s[t]+m*b[t])*c[t-L+m])

		else:
			st = alpha*(x[t]/c[t-L]) + (1-alpha)*(s[t-1]+b[t-1])
			s.append(st)

			bt = beta*(s[t] - s[t-1]) + (1-beta)*b[t-1]
			b.append(bt)

			ct = gama*(x[t]/s[t]) + (1-gama)*c[t-L] 
			c.append(ct)

			forecast.append((s[t]+m*b[t])*c[t-L+m])	
	# print len(s),len(b),len(c),len(forecast)
	return s,b,c,forecast


#helper function for division used in "create_pred_seq_3_m_approximate" function
def Calculate_division_l(a,b):
	return float(a)/float(b) 

def Calculate_division_s(a,b):
	return float(a)/float(b)

"""
Triple Exponential Smoothing with Multiplicative Seasonality with Approximation has seven parameters alpha, beta, gamma, N, L, cdash, sdash. 
Here  sdash is varied from within 19.0, 24.0, 30.0 for errors. 
'cdash' is the approximate value of c to be used for pseudo-division, there's no need to change, as for sales data or temperature data, c is always close to 1.0.
'sdash' is the approximate value of s to be used for pseudo-division. Can be calculated as an average of all current data.
"""
def create_pred_seq_3_m_approximate(x, alpha, beta, gamma, alpha_terms, beta_terms, gamma_cycles, N, L, m):

	alpha=alpha*.01
	beta =beta *.01
	gamma =gamma *.01

	#calculation of initial trend terms.
	b_add = 0
	b_sub = 0 

	for t in range(1,L+1):
		b_sub += x[t]

	for t in range(L+1,L+L+1):
		b_add += x[t]

	b1 = (b_add-b_sub)/L/L
	
	#calculation of initial seasonality terms.
	initial_season = [None]
	for i in range(1,L+1):	
		cval = 0
		for j in range(N):
			val = 0
			for k in range(1,L+1):
				val+=x[L*j+k]
			A = val/L
			cval += x[L*j+i]/A

		initial_season.append(cval/N)

	#number of values in the data 
	data_len=len(x)
	
	#calculation of level prime terms starts from here onwards.
	l_prime = [x[0]]
	s_prime=[None]

	data_l=[x[0]]
	data_s=[]
	
	#Initialize L+1 terms of seasonality as provided initially and calculate L+1 level terms as they are independent of seasonality. 
	for i in range(1,L+1):
		if (i<=alpha_terms):
			constant_l=[alpha]
			for t in range(i):
				if (t+1==i):
					constant_l.append((1-alpha)**(t+1))
				else:
					constant_l.append(alpha*(1-alpha)**(t+1))

			data_l.insert(0,x[i])
			temp_l=np.matmul(constant_l,data_l)
			l_prime.append(temp_l)
			#For seasonality calculations
			s_prime.append(initial_season[i])
			data_s.append(initial_season[i])
		
		else:
			data_l.insert(0,x[i])
			data_l.pop()

			temp_l=np.matmul(constant_l,data_l)
			l_prime.append(temp_l)
			#For seasonality calculations
			s_prime.append(initial_season[i])
			data_s.append(initial_season[i])


	#From L+1 terms onwards seasonality and level terms are interrelated and one is used for another calculations
	for i in range(L+1,data_len):
		#Calculation of level terms
		if (i<=alpha_terms):
			constant_l=[alpha]
			for t in range(i):
				if (t+1==i):
					constant_l.append((1-alpha)**(t+1))
				else:
					constant_l.append(alpha*(1-alpha)**(t+1))
		
			l_div=Calculate_division_l(x[i],s_prime[i-L])
			data_l.insert(0,l_div)

			temp_l=np.matmul(constant_l,data_l)
			l_prime.append(temp_l)

		else:
			l_div=Calculate_division_l(x[i],s_prime[i-L])
			data_l.insert(0,l_div)
			data_l.pop()

			temp_l=np.matmul(constant_l,data_l)
			l_prime.append(temp_l)
		
		#Calculations of seasonality terms.
		#calculate data cycle to check required number of terms.
		cycle=int(math.floor((i-1)/L))
		if (cycle<=gamma_cycles):
			constant_s=[gamma]
			for k in range(cycle):
				if (k+1==cycle):
					constant_s.append((1-gamma)**(k+1))
				else:
					constant_s.append(gamma*(1-gamma)**(k+1))

			#Prepare the vector for multiplication.
			s_div=Calculate_division_s(x[i],l_prime[i])
			data_s.append(s_div)

			temp_season=0
			#cycle+1 is because we started form L onwards not 0 onwards.
			for k in range(cycle+1):
				if (k+1==cycle):
					temp_season=temp_season + constant_s[k]*data_s[(i-1-(k*L))]
				else:
					temp_season=temp_season + constant_s[k]*data_s[(i-1-(k*L))]
			s_prime.append(temp_season)

		else:
			#Prepare the vector for multiplication.
			s_div=Calculate_division_s(x[i],l_prime[i])
			# print x[i],l_prime[i],s_div
			data_s.append(s_div)

			temp_season=0
			start_position=len(constant_s)
			for k in range(start_position):
				# print "i-1-(k*L)::",i-1-(k*L)
				# print "data_s[i-1-(k*L)]::",data_s[i-1-(k*L)]
				# print "constant_s[k]::",constant_s[k]
				temp_season=temp_season + constant_s[k]*data_s[i-1-(k*L)] 
			s_prime.append(temp_season)
			# print temp_season
	# print constant_s
	# print data_s


	#For calculating trend prime terms
	t_prime=[b1]
	data_t= [b1]

	for i in range(1,data_len):
		if (i<=beta_terms):
			constant_t=[beta]

			for j in range(i):
				if (j+1==i):
					constant_t.append((1-beta)**(j+1))
				else:
					constant_t.append(beta*(1-beta)**(j+1))
			
			data_t.insert(0,(l_prime[i]-l_prime[i-1]))
			temp_t=np.matmul(constant_t,data_t)
			t_prime.append(temp_t)

		else:
			data_t.insert(0,(l_prime[i]-l_prime[i-1]))
			data_t.pop()

			temp_t=np.matmul(constant_t, data_t)
			t_prime.append(temp_t)


	#Calculate the value of level double prime
	l_prime_prime=[0]
	for i in range(1,data_len):
		if (i<=alpha_terms):
			constant_l=[alpha]
			temp=0
			for t in range(i):
				constant_l.append((1-alpha)**(t+1))

			for j in range(len(constant_l)):
				temp=temp + constant_l[j]*t_prime[i-j]
			l_prime_prime.append(temp)

		else:
			temp=0
			for j in range(len(constant_l)):
				temp=temp + constant_l[j]*t_prime[i-j]
			l_prime_prime.append(temp)
	
	# Calculate the value of actual level as level=l_prime + l_prime_prime + level_prime_prime
	level=[]
	for i in range(data_len):
		level.append(l_prime[i] + l_prime_prime[i])
		# print level


	#Calculate forecast based on the calculated values of level trend and seasonality
	forecast= [None] 
	while(len(forecast)!=(m)):
		forecast.append(None)

	for t in range(data_len):
		if t <L:
			forecast.append(l_prime[t]+m*t_prime[t])
		elif (t==L):
			forecast.append((l_prime[t]+m*t_prime[t])*s_prime[t-L+m])
		else: 
			forecast.append((l_prime[t]+m*t_prime[t])*s_prime[t-L+m])


	return l_prime,t_prime,s_prime,forecast


	'''
	#Preprocessing for seasonality calculation.	
	New_data=[]
	for i in range(data_len):
		if (i<=L):
			New_data.append(initial_season[i])
		else:
			New_data.append(x[i]-l_prime[i-1]-t_prime[i-1])	

	#For calculating seasonality prime terms (gamma terms are in cycles)
	s_prime=[None]			
	for i in range(1,L+1):
		s_prime.append(initial_season[i])

	for i in range(L+1,data_len):
		#calculate data cycle to check required number of terms.
		cycle=int(math.floor((i-1)/L))
		if (cycle<=gamma_cycles):
			constant_s=[gamma]
			for k in range(cycle):
				if (k+1==cycle):
					constant_s.append((1-gamma)**(k+1))
					# constant_s=[k/sum(constant_s) for k in constant_s]
				else:
					constant_s.append(gamma*(1-gamma)**(k+1))

			temp_season=0
			#cycle+1 is because we started form L onwards not 0 onwards.
			for k in range(cycle+1):
				if (k==cycle):
					temp_season=temp_season + constant_s[k]*initial_season[(i-(k*L))]
				else:	
					temp_season=temp_season + constant_s[k]*New_data[(i-(k*L))]
			s_prime.append(temp_season)

		else:
			temp_season=0
			start_position=len(constant_s)
			print "start_position::",start_position
			for k in range(start_position+1):
				print "(i-(k*L))::",(i-(k*L))
				print k
				temp_season=temp_season + constant_s[k]*New_data[(i-(k*L))] 
			s_prime.append(temp_season)

	#Calculate forecast based on the calculated values of level trend and seasonality
	forecast= [] 
	while(len(forecast)!=(m)):
		forecast.append(None)

	for t in range(data_len):
		if t <L:
			forecast.append(l_prime[t]+m*t_prime[t])
		elif (t==L):
			forecast.append(l_prime[t]+m*t_prime[t]+s_prime[t-L+m])
		else: 
			forecast.append(l_prime[t]+m*t_prime[t]+s_prime[t-L+m])
	
	return l_prime,t_prime,s_prime,forecast

	'''























































































	'''
	forecast.append(s[0]+m*b[0])
	for t in range(1,len(x)):
		if t<=L:
			yt = alpha*x[t] + (1-alpha)*y[t-1]
			y.append(yt)
			bt = beta*(yt - y[t-1]) + (1-beta)*b[t-1]
			b.append(bt)
			st = alpha*x[t] + (1-alpha)*(s[t-1]+b[t-1])
			s.append(st)
			if t < L:
				forecast.append(st+bt)
			else: 
				forecast.append((st+bt)*c[t-L+1])

		else:
			yt = alpha*x[t] + (1-alpha)*y[t-1]
			y.append(yt)
			bt = beta*(yt - y[t-1]) + (1-beta)*b[t-1]
			b.append(bt)
			ct = gama*y[t]/(y[t-1]+b[t-1]) + (1-gama)*c[t-L] #ct = gama*x[t]/(y[t]) + (1-gama)*c[t-L] 
			c.append(ct)
			st = alpha*x[t]/c[t-L] + (1-alpha)*(s[t-1]+b[t-1])
			s.append(st)
			forecast.append((st+m*bt)*c[t-L+m])	
	return forecast

"""
Prediction using Linearized Exp Smoothing using only 5 previous data points (helper function)
"""

def get_final_pred_m_triple_linear(data, alpha, beta, gama, L, m):
	x = []
	y = []
	b = []
	c = []

	for i in range(L+15):
		x.append(data[len(data)-1-i])
		y.append(None)
		b.append(None)
		c.append(None)

	for i in range(L+11):
		yt = alpha*x[i] + alpha*(1-alpha)*x[i+1] + alpha*(1-alpha)**2*x[i+2] + alpha*(1-alpha)**3*x[i+3] + alpha*(1-alpha)**4*x[i+4]
		y[i] = yt

	for i in range(L+6):
		bt = beta*(y[i] - y[i+1]) + beta*(1-beta)*(y[i+1] - y[i+2]) + beta*(1-beta)**2*(y[i+2] - y[i+3]) + beta*(1-beta)**3*(y[i+3] - y[i+4]) + beta*(1-beta)**4*(y[i+4] - y[i+5])
		b[i] = bt

	for i in range(6):
		ct = gama*y[i+L-m]/(y[i+L-m+1] + b[i+L-m+1])
		c[i+L-m] = ct

	s = alpha*x[0]/c[L] + (1-alpha)*b[1] + alpha*(1-alpha)*x[1]/c[L+1] + (1-alpha)**2*b[2] + alpha*(1-alpha)**2*x[2]/c[L+2] + (1-alpha)**3*b[3] + alpha*(1-alpha)**3*x[3]/c[L+3] + (1-alpha)**4*b[4] + alpha*(1-alpha)**4*x[4]/c[L+4] + (1-alpha)**5*b[5] 

	f = (s + m*b[0])*c[L-m]

	return f

"""
To create a sequence approximation main function.for multiplication.

"""	

def create_pred_seq_3_m_triple_linear(x, alpha, beta, gama, L, m):
	forecast = []
	for i in range(L+15):
		forecast.append(None)

	for i in range(L+15,len(x)+1):
		pred_val = get_final_pred_m_triple_linear(x[:i], alpha, beta, gama, L, m)
		forecast.append(pred_val)

	return forecast


"""
Triple Exponential Smoothing Multiplicative Division and Pseudo-Division
"""

def create_pred_seq_3_m_bd(x, alpha, beta, gama, N, L, m, cdash, sdash):
	s = [x[0]]

	b_add = 0
	b_sub = 0 
	for t in range(1,L+1):
		b_sub += x[t]

	for t in range(L+1,L+L+1):
		b_add += x[t]

	b = [(b_add-b_sub)/L/L]
	
	c = [None]
	for i in range(1,L+1):	
		cval = 0
		for j in range(N):
			val = 0
			for k in range(1,L+1):
				val+=x[L*j+k]
			A = val/L
			cval += x[L*j+i]/A

		c.append(cval/N)

	
	forecast = [None] 
	while(len(forecast)!=(m)):
		forecast.append(None)

	forecast.append(s[0]+m*b[0])
	for t in range(1,len(x)):
		if t<=L:
			st = alpha*x[t] + (1-alpha)*(s[t-1]+b[t-1])
			s.append(st)
			bt = beta*(st - s[t-1]) + (1-beta)*b[t-1]
			b.append(bt)
			if t < L:
				forecast.append(st+bt)
			else: 
				forecast.append((st+bt)*c[t-L+1])

		else:
			st = alpha*((-x[t]/cdash**4)*c[t-L]**3 + (4*x[t]/cdash**3)*c[t-L]**2 - (6*x[t]/cdash**2)*c[t-L] + 4*x[t]/cdash) + (1-alpha)*(s[t-1]+b[t-1])
			s.append(st)
			bt = beta*(st - s[t-1]) + (1-beta)*b[t-1]
			b.append(bt)
			stemp = (s[t-1]+b[t-1])/sdash #stemp = s[t]/sdash
			# print(stemp)
			ct = gama*x[t]/sdash*(-stemp**3 + 4*stemp**2 - 6*stemp + 4) + (1-gama)*c[t-L]
			c.append(ct)
			forecast.append((st+m*bt)*c[t-L+m])	
	return forecast

	'''