import matplotlib.pyplot as plt 
import csv
import sklearn.metrics as sk
import math
import numpy as np
import decimal
import glob
decimal.setcontext(decimal.Context(prec=40))
import warnings
warnings.filterwarnings("ignore", category=RuntimeWarning) 


def do_error_analysis(x,s,fil,file_name,alpha,beta=False,gamma=False):

	forecast_errors = [x[i]-s[i] for i in range(len(x))]
	relative_errors = [abs(forecast_errors[i]/x[i]) if x[i] != 0 else 0 for i in range(len(x))]
	Mean_Forecast_Error=sum(forecast_errors)*1.0/len(forecast_errors)
	MAE=sk.mean_absolute_error(x,s)
	RMSE=math.sqrt(sk.mean_squared_error(x,s))
	MAPE=sum(relative_errors)*100.0/len(relative_errors)

	# print "Mean Forecast Error: ", Mean_Forecast_Error
	# print "Mean Absolute Error: ", MAE
	# print "Root Mean Squared Error: ",RMSE 
	# print "Mean Absolute Percentage Error (out of 100%): ", MAPE
	fil.write("%s," %file_name)
	fil.write("%s," %alpha)
	fil.write("%s," %beta)
	fil.write("%s," %gamma)
	fil.write("%s," %Mean_Forecast_Error)
	fil.write("%s," %MAE)
	fil.write("%s," %RMSE)
	fil.write("%s\n" %MAPE)

def read_file(file_name):
	read_data=open(file_name,"r")
	time=[]
	data=[] 
	firstline=1
	for line in read_data: 
		if firstline:
			firstline=0
		else:
			x=line.split(',') 
			for i in range(len(x)):
				# print x[i]
				if i==0:
					time.append(x[i])
				if i==2:
					# print x[i]
					data.append(x[i]) 
	read_data.close()
	data =[float(i) for i in data]
	return time,data
