'''
Run this file to train and obtain alpha ,beta and gamma values using .3 percent of the data of the data file
then use the obtined optimal vaules to forcast the test data.

This program contains both multiplication and addition forecast.
please uncomment accordingly to obtain the necessary technique of forecast.
'''
import os
import shutil
import pandas as pd
from subprocess import call
import matplotlib.pyplot as plt 
from os import listdir
from os.path import isfile, join
import Triple_Exponential as Triple
import Common_functions as Common
import math



#Function to calculate number of terms for alpha.
def number_terms(alpha,data_len):
	alpha=alpha*.01
	value=1
	terms=0
	for i in range(data_len):
		if (value<1.99999999):
			value=value+alpha*(1-alpha)**i
			terms=terms+1
	return terms

#Function to calculate number of terms for beta and gamma respectively.
def number_terms1(beta,data_len):
	beta=beta*.01
	value=1
	terms=0
	cycle=int(math.floor(data_len/12))
	for i in range(cycle):
		if (value<1.9999999):
			value=value+beta*(1-beta)**i
			terms=terms+1
	return terms	

#Obtain the currenct directory
curent_dir= os.getcwd()
previous_dir=os.path.dirname(curent_dir)
mypath=previous_dir + str('/Data/')



#Additive code starts from here onwards.
overall_err_file=curent_dir + str("/Forecast_Mul_files/") + str('Optimal_paramters.csv')
err_file=open(overall_err_file,'w',0)

#test error file for different data sets 
test_err_file=curent_dir + str("/Forecast_Mul_files/") + str('Normal_test_err.csv')
test_err_file=open(test_err_file,'w',0)
test_err_file.write("File_name,Alpha,Beta,gamma,Mean_Err,MAE,RMSE,MAPE_PC\n")

#test error file for different approximate data sets 
test_err_file1=curent_dir + str("/Forecast_Mul_files/") + str('Approx_test_err.csv')
test_err_file1=open(test_err_file1,'w',0)
test_err_file1.write("File_name,Alpha,Beta,gamma,Mean_Err,MAE,RMSE,MAPE_PC\n")


#Read all data file names from data folder
onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]
# onlyfiles = ['RSFSDP.csv']

for file_name in onlyfiles:
	print file_name
	#obtain the complete file name with location.
	location=mypath+str(file_name)

	#read the date and data from the file.
	date,data=Common.read_file(location)

	#Divide the data into train and test. Use 30% for training and remaing for testing. 
	train=int(round(.3*len(data)))
	test =int(len(data)-train)

	#Divide the data into two parts training and testing
	train_data=data[:train]
	test_data=data[train:]

	#remove  '.csv' from the file name. 
	filename=file_name.replace(".csv","")

	
	#Activate this for multiplicative seasonality forcasting
	#Create a file to write all errors calculated for different values of alpha,beta,gamma,N,L. 
	#create a file to write the train data error

	err_file_name=curent_dir + str("/Forecast_Mul_files/Train_Error/") + filename + str('_Error.csv')
	fil = open(err_file_name, 'w',0)
	fil.write("File_name,Alpha,Beta,Gamma,Mean_Err,MAE,RMSE,MAPE_PC\n")
	
	#Define the forecat parameters
	m=1
	L=12
	N=len(train_data)/12

	#Find all combinations of alpha,beta,gamma keeping N=number of complete cycles and L=length of a cycle constant for optimal parameter finding.
	for alpha in range(5,100,5):
		for beta in range(5,100,5):
			for gamma in range(5,100,5):
				level,trend,seasonal,forecast1 = Triple.create_pred_seq_3_mul(train_data, alpha,beta,gamma,N,L,m)
				Common.do_error_analysis(train_data,forecast1[1:],fil,file_name,alpha,beta,gamma)
	fil.close()	

	#Read file and obtain the minimum vaules of alpha and beta and gamma of the training forecast.
	run_data=pd.read_csv(err_file_name) 
	# print data.describe()
	# print data[data["MAPE_PC"] == data["MAPE_PC"].min()]
	row=run_data[run_data["MAPE_PC"] == run_data["MAPE_PC"].min()]
	alpha, beta, gamma = row["Alpha"] .values.tolist()[0], row["Beta"] .values.tolist()[0] ,row["Gamma"] .values.tolist()[0]
	err_file.write("%s,%s,%s,%s\n" %(file_name,alpha,beta,gamma,))

	N=len(data)/12

	#Forecast the data values 
	level,trend,seasonal,forecast = Triple.create_pred_seq_3_mul(data, alpha, beta, gamma, N, L, m)
	
	#Save forecasted data into a file
	forecasted_file_name=open(curent_dir + "/Forecast_Mul_files/Forecasted_data/" + str(file_name), 'w',0)
	forecasted_file_name.write("Data,level,trend,season,Forecast\n")
	
	for i in range(len(data)):
		forecasted_file_name.write("%s,%s,%s,%s,%s\n" %(data[i],level[i],trend[i],seasonal[i],forecast[i+1]))
	forecasted_file_name.close()

	#Find the test forecast values.
	# test_forecast=forecast[train:]
	# Common.do_error_analysis(data,forecast[1:],test_err_file,file_name,alpha,beta,gamma)

	test_forecast=forecast[train+1:]
	Common.do_error_analysis(test_data,test_forecast,test_err_file,file_name,alpha,beta,gamma)



	#Approximate forecasted data
	#define number of terms for forecast calculation.
	data_len=len(data)
	alpha_terms=number_terms(alpha,data_len) 
	beta_terms=number_terms(beta,data_len)
	gamma_cycles=number_terms1(gamma,data_len)	
	print "alpha_terms,beta_terms,gamma_cycles::",alpha_terms,beta_terms,gamma_cycles


	#Calculate forecasting using normal equations
	App_level,App_trend,App_seasonality,App_forecast =Triple.create_pred_seq_3_m_approximate(data,alpha,beta,gamma,alpha_terms,beta_terms,gamma_cycles,N,L,m)

	# Save approximate forecast data into a file
	forecasted_file_name1=open(curent_dir + "/Forecast_Mul_files/Approximat_Forecasted_data/" + str(file_name), 'w',0)
	forecasted_file_name1.write("Data,App_level,App_trend,App_seasonality,App_forecast\n")
	
	for i in range(len(data)):
		forecasted_file_name1.write("%s,%s,%s,%s,%s\n" %(data[i],App_level[i],App_trend[i],App_seasonality[i],App_forecast[i+1]))
	forecasted_file_name1.close()

	# #Find the test forecast values.
	# test_forecast=forecast[train:]
	# Common.do_error_analysis(data,forecast[1:],test_err_file,file_name,alpha,beta,gamma)

	test_forecast1=App_forecast[train+1:]
	# Common.do_error_analysis(test_data,test_forecast1,test_err_file1,file_name,alpha,beta,gamma)
	Common.do_error_analysis(data,App_forecast[1:],test_err_file1,file_name,alpha,beta,gamma)



	g_filename=file_name.replace(".csv",".png")
	gaph_folder=curent_dir + str("/Forecast_Mul_files/Graphs/") + g_filename

	plt.plot(data,'black',linewidth=.3 ,label='Original_data')#,  marker='o')
	plt.plot(forecast[1:],'red',linewidth=.3 ,label='Normal_Forecast')#,  marker='o')
	plt.plot(App_forecast[1:],'blue',linewidth=.3 ,label='Approx_Forecast')#,  marker='o')
	
	plt.title(file_name)
	plt.xlabel('Time')
	plt.ylabel('Values')
	plt.legend()
	# plt.show()
	plt.savefig(gaph_folder, dpi = 500)
	plt.close()


err_file.close()
test_err_file1.close()
test_err_file.close()
