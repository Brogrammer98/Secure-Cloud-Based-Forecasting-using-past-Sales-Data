import csv
import sklearn.metrics as sk
import math
import numpy as np
import decimal
import glob
decimal.setcontext(decimal.Context(prec=40))
import warnings
warnings.filterwarnings("ignore", category=RuntimeWarning) 

x=float(input("Enter the value of x:"))
print "Str division is ::",1/x

#############approx method ################
d=input("Enter multiplication depth::")
a_0=2-x
b_0=1-x
for i in range(d):
	b_0=b_0*b_0
	a_0=a_0*(1+b_0)
print a_0